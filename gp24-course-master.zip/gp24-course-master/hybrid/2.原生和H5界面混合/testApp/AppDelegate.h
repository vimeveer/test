//
//  AppDelegate.h
//  testApp
//
//  Created by lurongtao on 2019/4/16.
//  Copyright © 2019 lurongtao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

