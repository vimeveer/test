#import "ViewController.h"
#import <WebKit/WebKit.h>

@interface ViewController ()
@property(strong, nonatomic) UIWebView *webview;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //    获得手机的屏幕大小
    CGRect rect = CGRectMake(50, 50, self.view.frame.size.width-100, self.view.frame.size.height-500);
    
    //    创建能够打开网页的窗口在手机上是 webview
    self.webview = [[UIWebView alloc] initWithFrame:rect];
    
    //   关闭弹簧效果
    self.webview.scrollView.bounces = NO;
    
    
    //     写请求,加载服务器请求
    NSString *path = @"https://lz190419.top/index/home";
    NSURL *url = [NSURL URLWithString: path];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    
    
    //    写请求，加载本地文件
//    NSString *path = [[NSBundle mainBundle] pathForResource:@"www/index.html" ofType:nil];
//    NSURL *url = [NSURL fileURLWithPath:path];
//    NSURLRequest *request = [NSURLRequest requestWithURL:url];

    
    //  窗口加载请求
    [self.webview loadRequest:request];
    //
    
    //    在手机程序上显示窗口
    [self.view addSubview:self.webview];
    
}
@end
