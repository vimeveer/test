const path = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const CopyPlugin = require("copy-webpack-plugin")
const { CleanWebpackPlugin } = require('clean-webpack-plugin')

module.exports = {
  entry: {
    "js/app": "./src/index.js"
  },

  output: {
    // 全部资源的base目录
    path: path.resolve(__dirname, '../dist/'),
    publicPath: '/',
  },

  resolve: {
    extensions: ['.js', '.json', '.jsx'],
    alias: {
      '@': path.resolve(__dirname, '../src')
    }
  },

  module: {
    rules: [
      // 配置解析JS的loader
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader'
        }
      },

      // css
      {
        test: /\.css$/,
        use: ['style-loader', "css-loader"] 
      },

      {
        test: /\.string$/,
        use: [
          {
            loader: path.resolve(__dirname, '../src/loaders/string-loader.js')
          },
          {
            loader: path.resolve(__dirname, '../src/loaders/string-loader2.js'),
            options: {
              prefix: '!!!'
            }
          }
        ]
      }
    ]
  },

  plugins: [
    new CleanWebpackPlugin(),

    new HtmlWebpackPlugin({
      filename: 'index.html',
      template: path.resolve(__dirname, '../public/index.html'),
      inject: 'body'
    }),

    new CopyPlugin({
      patterns: [
        { 
          from: "**/*",
          
          context: "./public/",

          globOptions: {
            dot: true,
            gitignore: true,
            ignore: ["**/index.html"]
          },

          // filter(resourcePath) {
          //   const extname = path.extname(resourcePath)
          //   if (extname === '.html') {
          //     return false
          //   }
          //   return true
          // }
        }
      ],
    })
  ]
}