import { combineReducers } from 'redux'
import counter from './counter-reducer'
import product from './products-reducer'

//combineReducers 接受两个参数，是两个Reducer
const reducer = combineReducers({
  counter,
  product
})

export default reducer