import { createStore, applyMiddleware } from 'redux'
import thunk from 'redux-thunk'
import m1 from './middlewares/m1'
import m2 from './middlewares/m2'

import reducer from './reducer'

// const middleware = applyMiddleware(thunk.withExtraArgument('abc'))

const middleware = applyMiddleware(m1, m2)

// 给createStore, 给它传了两个参数，第一是定义reducer, 第二个是注册的中间件
const store = createStore(reducer, middleware)

export default store