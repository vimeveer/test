const loadData = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve({
        id: '001',
        name: '变形金刚模型'
      })
    }, 2000)
  })
}

// 同步的ActionCreator
const loadDataSync = product => {
  return {
    type: 'loadData',
    product
  }
}

// 异步的ActionCreator
const loadDataAsync = () => {
  // actionCreator返回一个函数
  return (dispatch, getState, args) => {
    loadData().then((product) => {
      dispatch(loadDataSync(product))
    })
  }
}

export {
  loadDataAsync,
  loadDataSync
}