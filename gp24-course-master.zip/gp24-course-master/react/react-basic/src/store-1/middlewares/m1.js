const m1 = ({dispatch, getState}) => {
  return next => {
    return action => {
      next({
        type: action.type,
        abc: action.payload + 400
      })
    }
  }
}

export default m1