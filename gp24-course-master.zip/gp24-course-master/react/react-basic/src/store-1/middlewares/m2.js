const m2 = ({dispatch, getState}) => {
  return next => {
    return action => {
      next({
        type: action.type,
        payload: action.abc
      })
    }
  }
}

export default m2