const defaultState = {
  products: []
}

const reducer = (state = defaultState, action) => {
  switch(action.type) {
    case 'add': 
      // console.log('addadd')
      return state

    case 'testm':
      console.log(action.payload)
      return state

    case 'loadData':
      return {
        products: [
          ...state.products,
          action.product
        ]
      }

    default:
      return state
  }
}

export default reducer