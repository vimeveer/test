import { LOADDATA, DECREMENTINVENTORY } from '../action-types/ProdActionTypes'
import axios from 'axios'

export const loadDataSync = products => {
  return {
    type: LOADDATA,
    products
  }
}

export const loadDataAsync = () => {
  return async (dispatch) => {
    let result = await axios.get('/data.json')
    dispatch(loadDataSync(result.data.data))
  }
}

export const decrementInventory = product => {
  return {
    type: DECREMENTINVENTORY,
    product
  }
}