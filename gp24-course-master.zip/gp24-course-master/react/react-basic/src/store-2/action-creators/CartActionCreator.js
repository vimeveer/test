import { ADDPRODUCTTOCART, CULTOTALPRICE } from '../action-types/CartActionTypes'

export const addToCart = product => {
  return {
    type: ADDPRODUCTTOCART,
    product
  }
}

export const culprice = () => {
  return {
    type: CULTOTALPRICE
  }
}