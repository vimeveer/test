import { LOADDATA, DECREMENTINVENTORY } from '../action-types/ProdActionTypes'
import _ from 'lodash'

const defaultState = {
  all: []
}

const reducer = (state = defaultState, action) => {
  switch(action.type) {
    case LOADDATA:
      return {
        all: action.products
      }

    case DECREMENTINVENTORY:
      const all = _.cloneDeep(state.all)
      const product = all.find(p => p.id === action.product.id)
      product.inventory--
      return {
        all
      }

    default:
      return state
  }
}

export default reducer