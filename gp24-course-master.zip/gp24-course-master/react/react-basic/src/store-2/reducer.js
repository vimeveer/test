import { combineReducers } from 'redux'
import product from './reducers/prod-reducer'
import cart from './reducers/cart-reducer'

const reducer = combineReducers({
  product,
  cart
})

export default reducer