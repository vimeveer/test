export const ADDPRODUCTTOCART = 'cart/add-product-to-cart'
export const CULTOTALPRICE = 'cart/culculate-total-price'