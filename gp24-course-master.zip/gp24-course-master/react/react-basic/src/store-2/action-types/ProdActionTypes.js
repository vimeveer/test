export const LOADDATA = 'products/loaddata'
export const DECREMENTINVENTORY = 'proudcts/decrement-inventory'