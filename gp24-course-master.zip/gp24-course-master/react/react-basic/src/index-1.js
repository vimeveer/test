import App from './App'

import React from 'react'
import ReactDOM from 'react-dom'

import store from './store/index'

import { Provider } from './context/storeContext'

// 将组建渲染到页面上
const render = () => {
  ReactDOM.render(
    // 渲染的组件
    <Provider value={{store}}>
      <App></App>
    </Provider>,
    // 定义渲染的位置
    document.querySelector('#root')
  )
}

render()

store.subscribe(() => {
  render()
})

// ReactDOM.render(
//   <div>q</div>,
//   document.querySelector('#app')
// )

// setTimeout(() => {
//   ReactDOM.unmountComponentAtNode(document.querySelector('#root'))
// }, 5000)