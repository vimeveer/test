// import React from 'react'
// import ReactDOM from 'react-dom'
// import { Provider } from 'react-redux'
// // 1、导入路由模块, BrowserRouter
// import { BrowserRouter as Router } from 'react-router-dom'

// // import "core-js/stable"
// // import "regenerator-runtime/runtime"

// import App from './App.jsx'
// import store from './store'

// import PathProvider from '@/components/PathContext'

// ReactDOM.render(
//   <Provider store={store}>
//     <Router>
//       <PathProvider>
//         <App></App>
//       </PathProvider>
//     </Router>
//   </Provider>,
//   document.querySelector('#root')
// )

// ReactDOM.unmountComponentAtNode(document.querySelector('#root'))


// import { add } from './math'

// console.log(add(4, 5))

// import './app.css'

// import { Machine, Appletree } from './PickApples'
// Machine.start()

// import './some-side-effectful-file.js'

// import { cube } from './math.js'

// console.log(cube(5))


// function getComponent() {
//   return import(/* webpackPrefetch: true, webpackChunkName: "lodash" */ 'lodash').then(module => {
//     const _ = module.default
//     var element = document.createElement('div')
//     element.innerHTML = _.join(['Hello', 'webpack'], ' ')
//     return element
//   }).catch(error => 'An error occurred while loading the component')
// }

// document.addEventListener('click', () => {
//   getComponent().then(component => {
//     console.log(0)
//     document.body.appendChild(component);
//   })
// })

// document.addEventListener('click', () => {
//   import(/* webpackPrefetch: true */ './AsyncPack.js').then( ({default: fun}) => {
//     fun()
//   })
// })
/**
 * webpack 项目优化
 * 1、tree shaking
 * 2、code spliting
 * 3、module lazy load
 * 4、prefetch
 * 5、code coverage rate
 */

import file from './file.string'
console.log(file)