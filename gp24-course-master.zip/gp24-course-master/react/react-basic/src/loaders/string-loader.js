module.exports = (source) => {
  const mySource = source.split('').reverse().join('')

  return `module.exports='${mySource}'`
}