const { getOptions } = require('loader-utils')

module.exports = function(source) {
  const callback = this.async()

  const options = getOptions(this)
  // return source + options.prefix

  setTimeout(() => {
    callback(null, source + options.prefix)
  }, 10000)
}