export const m1 = () => {
  console.log('hello')
}

export const m2 = () => {
  console.log('world')
}