import _ from 'lodash'
export default () => {
  var element = document.createElement('div')
  element.innerHTML = _.join(['Hello', 'webpack'], ' ')
  document.body.appendChild(element)
}