import React, { Component } from 'react';

class Button extends Component {
  render() {
    const { children: title, onBtnClick } = this.props

    return (
      <button onClick={onBtnClick}>{title}</button>
    )
  }
}

export default Button;