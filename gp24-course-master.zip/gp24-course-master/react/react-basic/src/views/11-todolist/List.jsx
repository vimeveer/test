import React, { Component, Fragment } from 'react';

import Button from './Button'

class List extends Component {
  handleClick = (url) => {
    return () => {
      window.open(url, '_blank')
    }
  }

  render() {
    return (
      <ul>
        {
          this.props.list.map((li, index) => {
            return (
              <li key={li.title + index}>
                {li.title}
                <Button onBtnClick={this.handleClick(li.url)}>进入</Button>
              </li>
            )
          })
        }
      </ul>
    );
  }
}

export default List;