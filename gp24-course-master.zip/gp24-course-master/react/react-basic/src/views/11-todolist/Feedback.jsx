import React, { Component } from 'react'
import List from './List'
import Form from './Form'

class Feedback extends Component {
  state = {
    list: [
      {
        title: 'a',
        url: 'https://www.baidu.com'
      }
    ]
  }

  handleReceiveItem = (item) => {
    this.state.list.push(item)
    this.setState({})
  }

  render() {
    return (
      <>
        <List list={this.state.list}></List>
        <Form onReceiveItem={this.handleReceiveItem}></Form>
      </>
    );
  }
}

export default Feedback;