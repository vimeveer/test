import React, { Component } from 'react';

class Index extends Component {
  state = {
    count: 0
  }

  constructor() {
    super()
    // this.handleClick = this.handleClick.bind(this)
  }

  // handleClick() {
  //   this.setState({
  //     count: 100
  //   })
  // }

  // 函数柯里化，解决函数传参问题
  handleClick = (num) => {
    return (e) => {
      this.setState({
        count: num
      })
    }
  }

  render() {
    return (
      <div>
        { this.state.count }
        <button onClick={this.handleClick(200)}>change count</button>
      </div>
    )
  }
}

export default Index;
