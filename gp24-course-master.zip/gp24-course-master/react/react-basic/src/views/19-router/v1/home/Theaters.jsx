import React, {useState} from 'react'

export default function theaters() {
  const [count] = useState(0)

  return (
    <div>
      theaters
    </div>
  )
}