import React from 'react'
import { useRouteMatch } from 'react-router-dom'

export default function Profile() {
  const match = useRouteMatch()
  // console.log(match)

  return (
    <div>
      profile
    </div>
  )
}
