import React from 'react'

export default function Page404() {
  return (
    <div>
      page not found.
    </div>
  )
}
