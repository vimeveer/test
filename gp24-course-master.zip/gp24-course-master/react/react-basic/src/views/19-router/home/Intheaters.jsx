import React from 'react'

export default function Intheaters() {
  return (
    <div>
      intheaters
    </div>
  )
}
