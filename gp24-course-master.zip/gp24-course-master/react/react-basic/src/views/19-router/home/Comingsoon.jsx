import React from 'react'

export default function Comingsoon() {
  return (
    <div>
      comingsoon
    </div>
  )
}
