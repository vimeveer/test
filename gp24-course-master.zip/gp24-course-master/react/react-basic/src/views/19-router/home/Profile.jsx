import React, { useState, useEffect } from 'react'
import { useLocation } from 'react-router-dom'

export default function Profile() {
  const { state, search } = useLocation()
  const [obj, setObj] = useState({})
  
  useEffect(() => {
    const searchObj = new URLSearchParams(search)
    setObj({
      name: searchObj.get('name'),
      age: searchObj.get('age')
    })
  }, [search])

  return (
    <div>
      profile 
      {/* {state.name} */}
      {JSON.stringify(obj)}
    </div>
  )
}
