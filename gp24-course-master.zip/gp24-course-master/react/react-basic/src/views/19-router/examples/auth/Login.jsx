import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import { authContext } from './authContext.js'

@withRouter
export default class Login extends Component {
  static contextType = authContext

  login = (history, from) => {
    return () => {
      this.context.signin(() => {
        history.replace(from)
      })
    }
  }

  render() {
    const { location, history } = this.props

    let { from } = location.state || { from: { pathname: "/" } };
    
    return (
      <div>
        <p>You must log in to view the page at {from.pathname}</p>
        <button onClick={this.login(history, from)}>Log in</button>
      </div>
    )
  }
}