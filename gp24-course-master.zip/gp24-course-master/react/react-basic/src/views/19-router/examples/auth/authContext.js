import React, { createContext } from 'react'

export const authContext = createContext()

const fakeAuth = {
  isAuthenticated: false,
  signin(cb) {
    fakeAuth.isAuthenticated = true;
    setTimeout(cb, 100); // fake async
  },
  signout(cb) {
    fakeAuth.isAuthenticated = false;
    setTimeout(cb, 100);
  }
}

class ProvideAuth extends React.Component {
  state = {
    user: null
  }

  setUser = user => {
    this.setState({
      user
    })
  }

  signin = cb => {
    return fakeAuth.signin(() => {
      this.setUser("user");
      cb();
    });
  };

  signout = cb => {
    return fakeAuth.signout(() => {
      this.setUser(null);
      cb();
    });
  };

  render() {
    return (
      <authContext.Provider
        value={{
          user: this.state.user,
          signin: this.signin,
          signout: this.signout
        }}
      >
        {this.props.children}
      </authContext.Provider>
    )
  }
}

export default ProvideAuth