import React, { Component } from 'react'

export default class PublicPage extends Component {
  render() {
    return (
      <h3>Public</h3>
    )
  }
}
