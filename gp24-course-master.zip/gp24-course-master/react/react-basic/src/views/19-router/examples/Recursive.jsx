import React from 'react'
import { 
  Route, 
  Switch, 
  Redirect,
  useRouteMatch,
  useParams,
  Link
} from 'react-router-dom'

export default function RecursiveExample() {
  return (
    <Switch>
      <Route path="/recursive/:id">
        <Person />
      </Route>
      <Route path="/recursive">
        <Redirect to="/recursive/0" />
      </Route>
    </Switch>
  );
}

function Person() {
  let { url } = useRouteMatch();
  console.log(url)
  let { id } = useParams();
  let person = find(parseInt(id));

  return (
    <div>
      <h3>{person.name}’s Friends</h3>

      <ul>
        {person.friends.map(id => (
          <li key={id}>
            <Link to={`${url}/${id}`}>{find(id).name}</Link>
          </li>
        ))}
      </ul>

      <Switch>
        <Route path={`${url}/:id`}>
          <Person />
        </Route>
      </Switch>
    </div>
  );
}

const PEEPS = [
  { id: 0, name: "Michelle", friends: [1, 2, 3] },
  { id: 1, name: "Sean", friends: [0, 3] },
  { id: 2, name: "Kim", friends: [0, 1, 3] },
  { id: 3, name: "David", friends: [1, 2] }
];

function find(id) {
  return PEEPS.find(p => p.id === id);
}
