import React, { Component } from 'react'

export default class ProtectedPage extends Component {
  render() {
    return (
      <h3>Protected Page</h3>
    )
  }
}
