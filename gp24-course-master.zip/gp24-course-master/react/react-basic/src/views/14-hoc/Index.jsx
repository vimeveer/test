import React, { Component } from 'react'

import titleHoc from './titleHoc'

@titleHoc('world')
class Hoc extends Component {
  componentDidMount() {
    console.log(this.props.title)
  }

  render() {
    return (
      <div>
        hello
      </div>
    );
  }
}

export default Hoc