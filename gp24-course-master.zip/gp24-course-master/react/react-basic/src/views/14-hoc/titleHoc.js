import React from 'react'

// 返回一个组件的函数，称之为高阶组件
const titleHoc = (title) => {
  return Comp => {
    return class extends React.Component {
      render() {
        return (
          <Comp
            title={title}
          ></Comp>
        )
      }
    }
  }
}

export default titleHoc