import React, { useState, useCallback } from 'react'
import Button from './Button'

export default function Index(props) {
  const [ color, changeColor ] = useState('red')

  const change = useCallback(
    () => {
      changeColor('blue')
    },
    [],
  )

  // const change = () => {
  //   changeColor('blue')
  // }

  return (
    <div>
      <span style={{color}}>hello</span>
      <Button change={change}></Button>
    </div>
  )
}
