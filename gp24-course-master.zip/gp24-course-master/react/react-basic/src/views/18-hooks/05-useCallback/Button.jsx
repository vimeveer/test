import React, { memo } from 'react'

export default memo(function Button(props) {
  console.log(100)
  return (
    <div>
      <button onClick={props.change}>change</button>
    </div>
  )
})
