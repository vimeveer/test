import React, { Component } from 'react'
import memoizeOne from 'memoize-one'

export default class ClassComputed extends Component {  
  state = {
    x: 100
  }

  cultimes = memoizeOne((num) => {
    return num * 2
  })

  change = () => {
    this.setState({
      x: 300
    })
  }

  componentDidMount() {
    // let fun = () => {
    //   return this.state.x * 2
    // }
    // let doubleX = memoizeOne(fun)
    // console.log(doubleX())

    // const add = (a, b) => {
    //   console.log(0)
    //   return a + b
    // };
    // const memoizedAdd = memoizeOne(add)
    // let value = memoizedAdd(2, 3)
    // let value2 = memoizedAdd(2, 3)
    // console.log(value)
  }

  

  render() {
    const result = this.cultimes(this.state.x)
    return (
      <div>
        {this.state.x} - 
        {result}
        <button onClick={this.change}>click</button>
      </div>
    )
  }
}
