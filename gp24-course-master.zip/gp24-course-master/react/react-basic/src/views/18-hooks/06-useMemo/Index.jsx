import React, { useState, useMemo, useCallback } from 'react'

export default function Index() {
  let [ num, setNum ] = useState(100)

  // 计算属性
  let doubleNum = useMemo(() => {
    console.log(0)
    return num * 2
  }, [num])

  // 貌似有“心智负担”
  // 懂得了套路，就自由了
  let change = useCallback(
    () => {
      setNum(500)
    },
    [],
  )

  return (
    <div>
      {num} - {doubleNum}
      <button onClick={change}>change</button>
    </div>
  )
}
