import { useState } from 'react'

const useCount = () => {
    // 把useState, 称之为 Hook
  // useState, 让我们的函数组件也有了状态
  let [count, setCount] = useState(0)

  const add = () => {
    setCount(count+1)
  }

  return {
    count,
    add
  }
}

export default useCount