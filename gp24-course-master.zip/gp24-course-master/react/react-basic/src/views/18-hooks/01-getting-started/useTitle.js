const useTitle = count => {
  document.title = count
}

export default useTitle