import React, { useState } from 'react'
import useCount from './useCount'
import useTitle from './useTitle'

export default function Index() {
  let {count, add} = useCount()
  useTitle(count)
  
  return (
    <div>
      {count}
      <button onClick={add}>add</button>
    </div>
  )
}
