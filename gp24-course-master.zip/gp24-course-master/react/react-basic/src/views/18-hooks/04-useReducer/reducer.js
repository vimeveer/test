export const defaultState = {
  color: 'red'
}

export const reducer = (state, action) => {
  if (action.type === 'change') {
    return {
      color: action.color
    }
  }
  
  return state
}