import React, { useReducer } from 'react'
import { defaultState, reducer } from './reducer'

export default function Other() {
  const [state] = useReducer(reducer, defaultState)

  return (
    <div>
      <span color={{color: state.color}}>world</span>
    </div>
  )
}
