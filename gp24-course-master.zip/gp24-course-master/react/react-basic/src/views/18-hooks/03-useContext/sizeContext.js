import { createContext } from 'react'

const sizeContext = createContext({
  size: '50px'
})

export default sizeContext