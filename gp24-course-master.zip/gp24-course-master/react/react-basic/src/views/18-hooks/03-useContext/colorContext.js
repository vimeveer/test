import { createContext } from 'react'

const colorContext = createContext({
  color: 'red'
})

export default colorContext