import { useRef, useEffect } from 'react'

function useUpdate(fn) {
  // useRef 创建一个引用
  const mounting = useRef(true)

  // 不能定义普通的变量，因为这样每次组件渲染的时候都会重新赋值
  // const mounting = true

  useEffect(() => {
    if (mounting.current) {
      mounting.current = false
    } else {
      fn()
    }
  })
}

export default useUpdate