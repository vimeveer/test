import React, { useEffect, useCallback, useState, useRef } from 'react'

export default function RefComponent() {
  const [count, setCount] = useState(0)

  let x = useRef(true)
  let y = useRef(null)

  useEffect(() => {
    if (x.current) {
      x.current = false
    } else {
      console.log(0)
      console.log(y.current)
    }
  })

  const handleClick = useCallback(
    () => {
      setCount(5000)
    },
    [],
  )

  return (
    <div ref={y}>
      hello {x.a} - {count}
      <button onClick={handleClick}>click</button>
    </div>
  )
}
