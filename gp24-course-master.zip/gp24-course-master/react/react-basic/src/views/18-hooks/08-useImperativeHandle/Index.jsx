import React, { useRef, useEffect, forwardRef, useImperativeHandle } from 'react'

const Input = forwardRef((props, ref) => {
  const inputRef = useRef(null)
  useImperativeHandle(ref, () => inputRef.current)
  return (
    // <input type="text" ref={inputRef} />
    <div ref={inputRef}>hello</div>
  )
})

export default function Index() {
  const ipt = useRef(null)

  useEffect(() => {
    // ipt.current.focus()
    console.log(ipt.current.innerHTML)
  }, [])

  return (
    <div>
      {/* <input ref={ipt} type="text" /> */}
      <Input ref={ipt}></Input>
    </div>
  )
}
