import React, { Component, lazy, Suspense } from 'react'

// lazy 可以使组件懒加载
const OtherComponent = lazy(() => import('./OtherComponent'))

const FallbackComponent = () => {
  return (
    <div>loading...</div>
  )
}

export default class Index extends Component {
  render() {
    return (
      <Suspense fallback={<FallbackComponent />}>
        <OtherComponent></OtherComponent>
      </Suspense>
    )
  }
}
