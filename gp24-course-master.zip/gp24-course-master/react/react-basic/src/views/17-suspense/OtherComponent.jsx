import React from 'react'

const OtherComponent = () => {
  return (
    <div>
      我已加载
    </div>
  )
}

export default OtherComponent