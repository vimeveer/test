import React, { Component } from 'react'

import Child1 from './Child1'
import Child2 from './Child2'

import { ColorProvider } from './ColorContextComp'

class Index extends Component {
  render() {
    return (
      // 在一个祖先组件定义公共状态
      <ColorProvider color="red">
        <div>
          <h1>Parent</h1>
          <Child1></Child1>
          <Child2></Child2>
        </div>
      </ColorProvider>
    );
  }
}

export default Index;