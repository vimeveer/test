import React from 'react'
import ColorContext, { Consumer } from './colorContext'

export default function GrandSon2(props) {
  return (
    <div>
      <Consumer>
        {
          value => {
            return (
              <span style={{color: value.color}}>
                {props.title()}
              </span>
            )
          }
        }
      </Consumer>
      
      <span>
        {props.children('!!!')}
      </span>
    </div>
  )
}

GrandSon2.defaultProps = {
  title: 'abc'
}

// GrandSon2.contextType = ColorContext