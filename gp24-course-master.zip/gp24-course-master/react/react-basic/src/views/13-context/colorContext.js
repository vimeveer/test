import { createContext } from 'react'

// 自定义context
const ColorContext = createContext({color: 'green'})

// Provider提供器组件， Consumer消费者组件
const { Provider, Consumer } = ColorContext

export default ColorContext

export {
  Provider,
  Consumer
}