import React, { Component } from 'react'
import ColorContext from './colorContext';

class GrandSon1 extends Component {
  static contextType = ColorContext

  componentDidMount() {
    // setTimeout(() => {
    //   this.context.color = 'blue'
    // }, 2000)
  }

  render() {
    return (
      <div style={{color: this.context.color}}>
        grandson1
      </div>
    );
  }
}

export default GrandSon1;