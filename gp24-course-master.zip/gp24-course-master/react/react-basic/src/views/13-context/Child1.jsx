import React, { Component } from 'react'
import GrandSon1 from './GrandSon1'

import ColorContext from './colorContext'

class Child1 extends Component {
  // contextType静态属性，用来定义context
  // this组件实例上的context属性就有值了
  static contextType = ColorContext

  componentDidMount() {
    // console.log(this)
  }

  render() {
    return (
      <div>
        <h2 style={{color: this.context.color}}>child1</h2>
        <GrandSon1></GrandSon1>
      </div>
    );
  }
}

export default Child1;