import React, { Component } from 'react'
import { ColorConsumer } from './ColorContextComp'

class GrandSon3 extends Component {
  render() {
    return (
      <ColorConsumer>
        {
          value => {
            return (
              <div style={{color: value.color}}>
                hello
                <button onClick={value.changeColor('purple')}>change color</button>
              </div>
            )
          }
        }
      </ColorConsumer>
    );
  }
}

export default GrandSon3;