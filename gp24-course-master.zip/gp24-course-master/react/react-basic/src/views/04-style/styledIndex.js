import styled from 'styled-components'

function getColor(props) {
  return props.color
}

const HelloWrapper = styled.div `
  color: ${props => getColor(props)};
  font-size: 50px;
`

export {
  HelloWrapper
}