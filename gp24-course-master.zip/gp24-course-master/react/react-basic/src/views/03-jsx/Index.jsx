import React, { Component, createElement } from 'react'

class Index extends Component {
  render() {
    return (
      <div>
        <a href="https://www.baidu.com">baidu</a>
      </div>
      // createElement(
      //   'div',
      //   {
      //     id: 100
      //   },
      //   createElement(
      //     'a',
      //     {
      //       href: 'https://www.baidu.com'
      //     },
      //     'baidu'
      //   )
      // )
    )
  }
}

export default Index;