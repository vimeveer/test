import React, { Component, createRef } from 'react'

// 非受控组件
class Index2 extends Component {
  state = {
    value: ''
  }

  constructor() {
    super()
    this.inptRef = createRef()
  }

  handleInput(e) {
    this.setState({
      value: e.target.value
    })
  }

  handleClick() {
    this.setState({
      // current才是我们要的那个Input
      value: this.inptRef.current.value
    })
  }

  render() {
    return (
      <div>
        <input 
          type="text"
          defaultValue="abc"
          ref={this.inptRef}
          // onInput={this.handleInput.bind(this)}
        />
        {this.state.value}
        <button onClick={this.handleClick.bind(this)}>click</button>
      </div>
    );
  }
}

export default Index2;