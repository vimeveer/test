import React, { Component } from 'react';

// 受控组件
class Index extends Component {
  state = {
    value: ''
  }

  handleChange(e) {
    this.setState({
      value: e.target.value
    })
  }

  render() {
    return (
      <div>
        <input
          type="text" 
          value={this.state.value}
          onChange={this.handleChange.bind(this)}
        />
        {this.state.value}
      </div>
    );
  }
}

export default Index;