export class Abc {
  render() {
    return 'abc'
  }
}