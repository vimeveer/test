import React, { Component, createRef } from 'react';

class Index2 extends Component {

  constructor() {
    super()
    this.file = createRef()
  }

  handleClick = () => {
    const name = this.file.current.files[0].name
    console.log(name)
  }

  render() {
    return (
      <div>
        <input 
          ref={this.file}
          type="file"
        />
        <button onClick={this.handleClick}>submit</button>
      </div>
    );
  }
}

export default Index2;