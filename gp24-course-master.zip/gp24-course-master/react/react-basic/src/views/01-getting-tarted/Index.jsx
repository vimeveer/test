import React from 'react'

import './app.styl'

import img from '@/assets/snip.png'

const App = () => {
  return (
    // jsx 解析需要React
    <div>
      <div>app</div>
      <img src={img} alt="" width="100" height="100" />
    </div>
  )
}

export default App