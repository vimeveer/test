import React from 'react'

// 无状态组件，木偶组件，影子组件，UI组件
const FunctionalComponent = (props) => {
  return (
    // html元素: React 元素，kebab-case
    <div>{props.title}</div>
  )
}

export default FunctionalComponent