import React, { Component } from 'react'
import FunctionalComponent from './FunctionalComponent'
import Child from './Child'

export default class ClassComponent extends Component {
  render() {
    return (
      <Child c="ccc" d="ddd">
        <FunctionalComponent title="hello react"></FunctionalComponent>
      </Child>
    )
  }

  componentDidMount() {
    console.log(100)
  }
}

// import React, { Component, CreateRef } from './Test'

// console.log(React)
// console.log(React.Component)