const React = {
  Component: () => {
    console.log(0)
  },

  CreateRef: () => {
    console.log(1)
  }
}

export default React

const { Component, CreateRef } = React

export {
  Component,
  CreateRef
}