import React, { Component } from 'react';

class Child extends Component {
  render() {
    const { c, d, children } = this.props
    return (
      <div>
        <h1>child</h1>
        {c} {d} {children}
      </div>
    )
  }
}

export default Child;