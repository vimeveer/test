import React, { Component } from 'react';

class Index extends Component {
  state = {
    count: 0,
    list: [
      <div key="001">hello</div>,
      <div key="002">world</div>
    ],
    html: '<h1>title</h1>'
  }

  render() {
    return (
      <div>
        {3 > 2 && this.state.count}
        
        {
          this.state.list.filter((li, index) => index === 0)
        }

        { this.state.html }

        <div dangerouslySetInnerHTML={{__html: this.state.html}}></div>

        <label htmlFor=""></label>
      </div>
    );
  }
}

export default Index;