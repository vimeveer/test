import React, { Component } from 'react';

class GrandSon extends Component {
  render() {
    return (
      <div>
        hello {this.props.name} {this.props.age}
      </div>
    );
  }
}

export default GrandSon;