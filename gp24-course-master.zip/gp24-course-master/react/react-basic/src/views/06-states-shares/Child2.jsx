import React, { Component } from 'react';

class Child2 extends Component {
  render() {
    return (
      <div>
        child2 { this.props.age } { this.props.name }
      </div>
    );
  }
}

export default Child2;