import React, { Component } from 'react'

import Child1 from './Child1'
import Child2 from './Child2'

class Index extends Component {
  state = {
    age: 18,
    name: ''
  }

  handleChangeAge(age) {
    this.setState({
      age
    })
  }

  handleChangeName(name) {
    this.setState({
      name
    })
  }

  render() {
    return (
      <div>
        <Child1 
          age={this.state.age}
          name={this.state.name}
          onChangeAge={this.handleChangeAge.bind(this)}
          onChangeName={this.handleChangeName.bind(this)}
        ></Child1>
        <Child2 age={this.state.age} name={this.state.name}></Child2>
      </div>
    );
  }
}

export default Index;