import React, { Component } from 'react'

import GrandSon from './GrandSon'

class Child1 extends Component {
  handleClick = () => {
    this.props.onChangeAge(20)
  }

  render() {
    let { age } = this.props

    return (
      <div>
        child1 {age}
        <button onClick={this.handleClick.bind(this)}>change age</button>
        <button onClick={() => this.props.onChangeName('gp24')}>change name</button>

        <GrandSon {...this.props}></GrandSon>
      </div>
    );
  }
}

export default Child1;