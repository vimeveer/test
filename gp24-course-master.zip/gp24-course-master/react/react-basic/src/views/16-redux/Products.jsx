import React, { Component } from 'react'
import { connect } from 'react-redux'
import { loadDataAsync, loadDataSync } from '../../store/actionCreator'

@connect(
  (state) => ({
    products: state.product.products
  }),

  // {
  //   type: 'loadData',
  //   product: {
  //     id: '001',
  //     name: 'gp24'
  //   }
  // }

  (dispatch) => ({
    loadData() {
      // 因为thunk中间件，我们就可以给dispatch传递函数
      // 中间件会拦截dispatch
      dispatch({
        type: 'testm',
        payload: 100
      })
    }
  })
)
class Products extends Component {

  componentDidMount() {
    // 在组件内部做副作用操作
    // loadData().then((product) => {
    //   this.props.loadData(product)
    // })
    this.props.loadData()
  }

  render() {
    return (
      <div>
        {
          this.props.products.map((p) => {
            return (
              <div key={p.name}>{p.name}</div>
            )
          })
        }
      </div>
    )
  }
}

export default Products