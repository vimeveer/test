import React, { Component } from 'react'
import { connect } from 'react-redux'

// 映射store里的state到组件的props上
const mapStateToProps = state => ({
  count: state.count
})

// 映射store里的dispatch到组件的props上
const mapDispatchToProps = dispatch => ({
  add() {
    dispatch({
      type: 'add'
    })
  }
})

class CounterComp extends Component {
  render() {
    const { count, add } = this.props
    return (
      <div>
        {count}
        <button onClick={add}>add</button>
      </div>
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(CounterComp)