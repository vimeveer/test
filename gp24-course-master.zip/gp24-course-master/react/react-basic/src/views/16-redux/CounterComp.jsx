import React, { Component } from 'react'
import { connect } from 'react-redux'

@connect(
  state => ({
    // 这里的状态有命名空间的概念
    count: state.counter.count
  }),
  
  dispatch => ({
    add() {
      // dispatch不用考虑命名空间，所有的reducer都是并列的
      dispatch({
        type: 'add'
      })
    }
  })
)
class CounterComp extends Component {
  render() {
    const { count, add } = this.props
    return (
      <div>
        {count}
        <button onClick={add}>add</button>
      </div>
    )
  }
}

export default CounterComp