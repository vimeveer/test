import { ADDPRODUCTTOCART, CULTOTALPRICE } from './actionTypes'
import { fromJS } from 'immutable'

const defaultState = fromJS({
  items: [],
  totalprice: 0
})

const reducer = (state = defaultState, action) => {
  switch(action.type) {
    case ADDPRODUCTTOCART:
      const index = state.get('items').findIndex(p => p.get('id') === action.product.get('id'))
      if (index !== -1) {
        return state.updateIn(['items', index, 'quantity'], p => p + 1)
      } else {
        const p = action.product.set('quantity', 1)
        return state.update('items', items => items.push(p))
      }

    case CULTOTALPRICE:
      const totalprice = state.get('items').reduce((value, p) => {
        value += p.get('price') * p.get('quantity')
        return value
      }, 0)

      return state.set('totalprice', totalprice)

    default:
      return state
  }
}

export default reducer