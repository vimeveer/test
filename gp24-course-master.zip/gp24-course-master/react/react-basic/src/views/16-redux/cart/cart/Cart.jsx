import React, { Component } from 'react'
import { connect } from 'react-redux'
import CartUi from './CartUi'

@connect(
  state => {
    return {
      products: state.getIn(['cart', 'items']),
      totalPrice: state.getIn(['cart', 'totalprice'])
    }
  }
)
export default class Cart extends Component {
  render() {
    return (
      <CartUi 
        products={this.props.products}
        totalPrice={this.props.totalPrice}
      ></CartUi>
    )
  }
}
