import React from 'react'

export default function CartUi(props) {
  return (
    <>
      <ul>
        {
          props.products.map(p => {
            return (
              <li key={p.get('id')}>
                {p.get('name')} - ￥{p.get('price')} x {p.get('quantity')} = ￥{p.get('price') * p.get('quantity')}
              </li>
            )
          })
        }
      </ul>
      <div>
        总价：￥{props.totalPrice}
      </div>
    </>
  )
}
