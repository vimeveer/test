import React from 'react'

export default function ProductsUi(props) {
  return (
    <ul>
      {
        props.products.map(p => {
          return (
            <li key={p.get('id')}>
              {p.get('name')} - ￥{p.get('price')}
              <button 
                onClick={() => props.addToCart(p)}
                disabled={p.get('inventory') <= 0}
              >
                放入购物车
              </button>
            </li>
          )
        })
      }
    </ul>
  )
}
