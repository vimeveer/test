/**
 * actionCreator的意义
 * 1、作为表示异步操作的内容在Redux
 * 2、可以将action暴露给其他的模块
 * 3、作为bindActionCreator的入参
 */


import { LOADDATA, DECREMENTINVENTORY } from './actionTypes'
import axios from 'axios'
import { fromJS } from 'immutable'

export const loadDataSync = products => {
  return {
    type: LOADDATA,
    products
  }
}

export const loadDataAsync = () => {
  return async (dispatch) => {
    let result = await axios.get('/data.json')
    dispatch(loadDataSync(fromJS(result.data.data)))
  }
}

export const decrementInventory = product => {
  return {
    type: DECREMENTINVENTORY,
    product
  }
}