import React, { Component } from 'react'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
// import { loadDataAsync, decrementInventory } from './actionCreator'
import * as prodActions from './actionCreator'
import { actionCreator as cartActions } from '../cart'

import ProductsUi from './ProductsUi'

@connect(
  state => ({
    products: state.getIn(['product', 'all'])
  })
)
export default class Products extends Component {
  constructor(props) {
    super(props)
    this.actions = bindActionCreators(
      {
        ...prodActions,
        ...cartActions
      }, 
      this.props.dispatch
    )
  }

  addToCart = (product) => {
    this.actions.addToCart(product)
    this.actions.decrementInventory(product)
    this.actions.culprice()
  }

  async componentDidMount() {
    // 直接调用通过bindActionCreator绑定过的actions
    this.actions.loadDataAsync()
  }

  render() {
    return (
      <ProductsUi 
        products={this.props.products}
        addToCart={this.addToCart}
      ></ProductsUi>
    )
  }
}
