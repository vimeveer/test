import { LOADDATA, DECREMENTINVENTORY } from './actionTypes'
import _ from 'lodash'
import { fromJS } from 'immutable'

const defaultState = fromJS({
  all: []
})

const reducer = (state = defaultState, action) => {
  switch(action.type) {
    case LOADDATA:
      // 简化操作reducer的state
      return state.set('all', action.products)

    case DECREMENTINVENTORY:
      let index = state.get('all').findIndex(p => p.get('id') === action.product.get('id'))
      return state.updateIn(['all', index, 'inventory'], inventory => inventory - 1)

    default:
      return state
  }
}

export default reducer