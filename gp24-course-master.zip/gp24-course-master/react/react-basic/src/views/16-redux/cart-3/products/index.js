import Products from "./Products"
import reducer from './reducer'
import * as productActions from './actionCreator'

export {
  Products,
  reducer,
  productActions
}