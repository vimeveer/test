import { ADDPRODUCTTOCART, CULTOTALPRICE } from './actionTypes'

export const addToCart = product => {
  return {
    type: ADDPRODUCTTOCART,
    product
  }
}

export const culprice = () => {
  return {
    type: CULTOTALPRICE
  }
}