import { ADDPRODUCTTOCART, CULTOTALPRICE } from './actionTypes'
import _ from 'lodash'

const defaultState = {
  items: [],
  totalprice: 0
}

const reducer = (state = defaultState, action) => {
  switch(action.type) {
    case ADDPRODUCTTOCART:
      const items = _.cloneDeep(state.items)
      const product = items.find(p => p.id === action.product.id)
      
      if (product) {
        product.quantity++
        return {
          items
        }
      } else {
        return {
          items: [
            ...state.items,
            {
              ...action.product,
              quantity: 1
            }
          ]
        }
      }

    case CULTOTALPRICE:
      const totalprice = state.items.reduce((value, p) => {
        value += p.price * p.quantity
        return value
      }, 0)

      return {
        ...state,
        totalprice
      }

    default:
      return state
  }
}

export default reducer