import React, { Component } from 'react'
import { Products } from './products'
import { Cart } from './cart'

class Index extends Component {
  render() {
    return (
      <div>
        <h1>产品信息</h1>
        <hr />
        <Products></Products>
        <h1>购物车信息</h1>
        <hr />
        <Cart></Cart>
      </div>
    )
  }
}


export default Index