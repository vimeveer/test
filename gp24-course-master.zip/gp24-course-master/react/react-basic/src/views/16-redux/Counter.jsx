import React, { Component } from 'react'

import { storeContext } from '../../context/storeContext'

import Counter2 from './Counter2'

export default class Counter extends Component {
  static contextType = storeContext

  handleClick = () => {
    const { dispatch, getState } = this.context.store
    dispatch({
      type: 'add'
    })
    // console.log(getState().count)
    // this.forceUpdate()
  }

  render() {
    const { getState } = this.context.store
    const { count } = getState()

    return (
      <div>
        {
          count
        }
        <button onClick={this.handleClick}>add</button>

        <Counter2></Counter2>
      </div>
    )
  }
}
