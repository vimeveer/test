import React from 'react'

export default function CartUi(props) {
  return (
    <>
      <ul>
        {
          props.products.map(p => {
            return (
              <li key={p.id}>
                {p.name} - ￥{p.price} x {p.quantity} = ￥{p.price * p.quantity}
              </li>
            )
          })
        }
      </ul>
      <div>
        总价：{props.totalPrice}
      </div>
    </>
  )
}
