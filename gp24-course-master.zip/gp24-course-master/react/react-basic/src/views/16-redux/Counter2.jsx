import React, { Component } from 'react'

import { storeContext } from '../../context/storeContext'

export default class Counter2 extends Component {
  static contextType = storeContext

  render() {
    return (
      <div>
        {this.context.store.getState().count}
      </div>
    )
  }
}
