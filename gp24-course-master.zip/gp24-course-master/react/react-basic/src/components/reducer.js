export const defaultState = {
  path: '/movies/intheaters'
}

export const reducer = (state, action) => {
  if (action.type === 'changePath') {
    return {
      path: action.path
    }
  }

  return state
}