import { combineReducers } from 'redux'
import { reducer as product } from '../views/16-redux/cart/products'
import { reducer as cart } from '../views/16-redux/cart/cart'

const reducer = combineReducers({
  product,
  cart
})

export default reducer