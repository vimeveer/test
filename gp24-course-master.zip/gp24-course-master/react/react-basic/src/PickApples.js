export class Machine {
  name = 'CNMO'

  start() {
    console.log('press the start button please.')
  }
}

export class Appletree {
  type = 'guoguang'

  shake() {
    console.log('I am shaking...')
  }
}
