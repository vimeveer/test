import Mock from 'mockjs'

Mock.mock('/api/products', () => {
  const data = Mock.mock({
    'products|2-5': [
      {
        'name': '@word(3,4)',
        'id': function() {
          return Math.random().toString(36).substring(7).split('').join('.')
        },
      }
    ]
  })
  return data
})

// const Mock = require('mockjs')

// const data = Mock.mock({
//   'products|2-5': [
//     {
//       'name': '@word(3,4)',
//       'id': function() {
//         return Math.random().toString(36).substring(7).split('').join('.')
//       },
//     }
//   ]
// })

// console.log(data)