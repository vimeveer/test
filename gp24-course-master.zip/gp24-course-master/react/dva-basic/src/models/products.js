import { query } from '../services/products'

export default {
  namespace: 'products',

  state: [],

  reducers: {
    delete(state, { payload: id }) {
      // 函数式编程的典型
      return state.filter(item => item.id !== id);
    },
    setProducts(state, action) {
      return action.data
    }
  },

  effects: {
    *loadData(action, { call, put }) {
      // let data = yield new Promise(resolve => {
      //   setTimeout(() => {
      //     resolve([
      //       { name: 'dva', id: 1 },
      //       { name: 'antd', id: 2 },
      //     ])
      //   }, 1000)
      // })

      let data = yield call(query, '/api/products')

      yield put({
        type: 'setProducts',
        data: data.products
      })
    }
  },

  subscriptions: {
    abc({ dispatch, history }) {  // eslint-disable-line
      console.log(100)
    },
  }
};