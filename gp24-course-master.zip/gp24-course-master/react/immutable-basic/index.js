/**
 * 为什么使用Immutable
 * 1、降低mutable带来的复杂度: 为了简化代码（redux的reducer的代码）
 * 2、结构共享，节省内存，提高性能
 */

const {
  Map,
  List,
  Seq,
  Range,
  fromJS,
  is
} = require('immutable')

// const state = {
//   str: '千锋教育',
//   obj: {
//     y: 1
//   },
//   arr: [1, 2, 3]
// }
// const newState = state

// console.log(newState === state)

// const state = {
//   str: '千锋教育',
//   obj: {
//     y: 1
//   },
//   arr: [1, 2, 3]
// }
// const newState = Object.assign({}, state)

// newState.str = '千锋教育H5学院'

// newState.obj.y = 100

// console.log(state.obj.y, newState.obj.y)

// const x = {
//   a: 100,
//   b: 200
// }

// const y = {
//   a: 100,
//   b: 200
// }

// console.log(JSON.stringify(x) === JSON.stringify(y))



// 案例一

// const map = Map({
//   x: 100,
//   y: 200
// })

// const map2 = Map({
//   x: 100,
//   y: 200
// })

// console.log(map === map2)
// console.log(map == map2)
// console.log(map.equals(map2))

// console.log(map.get('x'))
// const map2 = map.set('x', 100)
// console.log(map.get('x'))
// console.log(map2.get('x'))

// console.log(map === map2)
// console.log(map == map2)

// const map = Map({
//   x: 100
// })

// const map2 = map

// console.log(map === map2)

// const map3 =map2.set('x', 200)

// console.log(map.toObject())
// console.log(map2.toObject())
// console.log(map3.toObject())

// console.log(map === map3)

// const list = List(['a', 'b'])
// const list2 = list.push('c')
// const list3 = List([]).concat(list, list2)

// console.log(list.toArray())
// console.log(list2.toArray())
// console.log(list3.toArray())

// const map = Map({
//   x: 100,
//   y: 200
// })

// const map2 = map.map((value, key) => {
//   return value + 300
// })

// const str = map.join(':')

// console.log(str)
// console.log(map2.toObject())

// const map2 = map.map((v, k) => {
//   return k.toUpperCase()
// })
// console.log(map2.join())

// const arr = ['a', 'b']
// const obj = {
//   a: 100,
//   b: 200
// }

// const list = List(['c', 'd'])
// const map = Map({
//   c: 100,
//   d: 200
// })

// const map2 = map.merge(obj)
// console.log(map.toObject())
// console.log(map2.toObject())

// console.log(arr.concat(arr2))
// console.log(Object.assign(obj, obj2))

// console.log(arr.concat(list))
// console.log(list.concat(arr).toArray())

// const obj3 = {
//   ...obj,
//   ...obj2
// }

// console.log(obj3)

// const obj = {
//   x: 1,
//   y: 2,
//   z: 3
// }

// const seq = Seq(obj)

// const seq2 = seq.map(v => {
//   console.log(v)
//   return v * v
// })
// console.log('y:', seq2.get('y'))

// const oddSquares = Seq([ 1, 2, 3, 4, 5, 6, 7, 8 ])
//   .filter(x => {
// 		// console.log('filter x:' + x)
// 		return x % 2 !== 0
//   })
//   .map(x => {
// 		console.log('map x:' + x)
// 		return x * x
//   })

// console.log(oddSquares.toArray())
// console.log(oddSquares.get(1))

// const map = Map({ a: 1, b: 2, c: 3 })
// const lazySeq = Seq(map)
// const newMap = lazySeq
//   .flip()
//   .map(key => key.toUpperCase())
//   .flip()

// console.log(newMap.toObject())

// const aRange = Range(1, Infinity)
//   .skip(1000)
//   .map(n => -n) // -1001 -1002 -1003 -1004 ......
//   .filter(n => n % 2 === 0) // -1002 -1004 -1006 ......
//   .take(2) // -1002 -1004
//   .reduce((r, n) => r * n, 1)

// console.log(aRange)

// const x = {
//   a: 100,
//   b: {
//     c: ['a', 1000]
//   }
// }

// // const y = Map(x)
// const y = fromJS(x)

// console.log(y.get('b').get('c').get(0))

// const x = Map({
//   a: List(['a', 'b'])
// })

// console.log(x.toJS())

// const aList = List([ 1, 2, 3 ])
// const anArray = [ 0, ...aList, 4, 5 ]
// console.log(anArray)

// const nested = fromJS({ a: { b: { c: [ 3, 4, 5 ] } } })

// console.log(nested.get('a').get('b').get('c').get(1))
// console.log(nested.getIn(['a', 'b', 'c', 1]))
// let nested1 = nested.setIn(['a', 'b', 'c', 1], 444)
// console.log(nested1.toString())
// const nested2 = nested.updateIn(['a', 'b', 'c', 1], (v) => {
//   return v * 100
// })
// console.log(nested2.toString())

// const newNested = nested.withMutations((v) => {
//   console.log(v)
//   // v.setIn(['a', 'b', 'c', 1], 44)
//   // console.log(newNested.toString())
// })

// console.log(newNested.toString())

// const map = Map({
//   x: 100
// })

// const map2 = map.set('x', 100)

// console.log(is(map, map2))