import React, { useEffect } from 'react'
import { observer } from 'mobx-react'

function App({ store }) {
  const handleClick = () => {
    store.setState(store.state)
  }

  useEffect(() => {
    // store.initState()
    store.initState2()
  }, [])

  return (
    <div>
      { store.state.count } - { store.double.get() }
      {/* <button onClick={store.add}>+</button>
      <button onClick={minus}>-</button> */}
      <button onClick={handleClick}>add</button>
    </div>
  )
}

export default observer(App)
