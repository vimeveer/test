import { makeAutoObservable } from 'mobx'
function observableMaker(value) {
  return makeAutoObservable({
    value,
    minus() {
      this.value--
    }
  })
}

export default observableMaker