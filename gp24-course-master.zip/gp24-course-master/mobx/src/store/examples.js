const { observable, autorun, when, reaction } = require('mobx')

// const arr = observable(['a', 'b'])
// const obj = observable({
//   x: 100,
//   y: 200
// })

// const value = observable(0)

// autorun(() => {
//   // console.log(arr)
//   // console.log(arr.length)
//   // console.log(obj.z)
//   console.log(value.get())
// })

// value.set(100)

// arr.push('c')
// arr.length = 0
// arr[0] = 'aaa'

// obj.z = 300

const value = observable(101)

// when(
//   () => {
//     return value.get() > 100
//   },
//   () => {
//     console.log(value.get())
//   }
// )

reaction(
  () => {
    return value.get()
  },
  (value) => {
    console.log(value)
  }
)

value.set(1)