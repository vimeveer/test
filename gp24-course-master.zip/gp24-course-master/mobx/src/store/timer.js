import { 
  makeAutoObservable, 
  makeObservable,
  observable,
  action,
  computed
} from 'mobx'

class Timer {
  count = 0

  get doubleCount() {
    return this.count * 2
  }
  
  constructor() {
    // 将类里的状态变成可观察对象
    // 将类里的函数变成action
    // makeAutoObservable(this)
    makeObservable(this, {
      count: observable,
      doubleCount: computed,
      add: action.bound,
      minus: action
    })
  }

  // actions
  add() {
    // 更新状态
    this.count++
  }

  minus() {
    this.count--
  }
}

export default new Timer()