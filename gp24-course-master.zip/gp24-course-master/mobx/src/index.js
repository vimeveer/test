import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'
import App2 from './App2'

// import timerStore from './store/timer'
import countStore from './store/counter'

ReactDOM.render(
  // <App
  //   store={timerStore}
  // ></App>,
  <App2 store={countStore}></App2>,
  document.querySelector('#root')
)