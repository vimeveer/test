import React from 'react'
import { observer } from 'mobx-react'

// 工厂函数的用法，非类的用法
// import observableMaker from './store/observableMaker'
// const store = observableMaker(0)

function App({ store }) {
  // const add = () => {
  //   store.add()
  // }

  const minus = () => {
    store.minus()
  }

  return (
    <div>
      { store.count } - { store.doubleCount }
      <button onClick={store.add}>+</button>
      <button onClick={minus}>-</button>
    </div>
  )
}

export default observer(App)
