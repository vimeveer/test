module.exports = {
  mode: 'development',

  devtool: 'source-map',

  output: {
    filename: '[name].js',
  },

  module: {
    rules: [

      // 配置解析CSS loader
      {
        test: /\.styl$/,
        use: ['style-loader', "css-loader", "stylus-loader"] // compiles Styl to CSS
      },

      // 图片资源
      {
        test: /\.(png|svg|jpg|jpeg|gif)$/i,
        type: 'asset/resource',
        generator: {
          filename: 'images/[name][ext]'
        }
      },
    ]
  },

  devServer: {
    historyApiFallback: true,
    proxy: {
      '/ajax': {
        target: 'https://m.maoyan.com',
        changeOrigin: true
      },
    },
  },
}