module.exports = {
  presets: [
    // preset预设，表示一组插件（babel）的集合
    // env 是一组ES6-babel插件的集合
    ['@babel/preset-env', { 
      targets: "defaults",
      useBuiltIns: "usage", //entry, none
      corejs: 3
    }],

    // react 预设
    ["@babel/preset-react"]
  ],

  "plugins": [
    ["@babel/plugin-proposal-decorators", { "legacy": true }]
  ]
}


