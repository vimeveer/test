const set = () => {
  return 'localStorage.setItem("firstLoad", false)'
}

const get = () => {
  return 'localStorage.getItem("firstLoad")'
}

module.exports = {
  set,
  get
}