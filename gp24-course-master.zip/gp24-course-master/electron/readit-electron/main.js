const { app } = require('electron')

const openWindow = require('./modules/openWindow')

app.whenReady().then(() => {
  openWindow()
})

// 不提示安全警告
process.env['ELECTRON_DISABLE_SECURITY_WARNINGS'] = 'true'