const { ipcRenderer } = require('electron')

module.exports = {
  sendUrl: (url) => {
    ipcRenderer.send('page-url', url)
  },
  receiveData: (callback) => {
    ipcRenderer.on('page-data', (e, data) => {
      callback(data)
    })
  }
}