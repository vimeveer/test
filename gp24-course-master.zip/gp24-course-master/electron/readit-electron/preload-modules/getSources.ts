const { desktopCapturer } = require('electron')

const getSources = () => {
  return new Promise((resolve, reject) => {
    desktopCapturer.getSources({ 
      types: ['window'], 
      thumbnailSize: {
        width:1920, 
        height:1080
      } 
    }).then((resources) => {
      resolve(resources[0].thumbnail.toDataURL())
    }).catch((err) => {
      reject(err)
    }) 
  })
}

module.exports = getSources