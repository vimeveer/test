const { contextBridge } = require('electron')

// const getSources = require('./preload-modules/getSources.ts')
const { sendUrl, receiveData } = require('./preload-modules/captureDesktop.ts')

window.addEventListener('DOMContentLoaded', () => {

  // 暴露截屏接口
  // contextBridge.exposeInMainWorld('getSources', getSources)

  // 暴露传递url给主进程的函数
  contextBridge.exposeInMainWorld('sendUrl', sendUrl)

  // 定义接收数据的接口
  contextBridge.exposeInMainWorld('receiveData', receiveData)
})