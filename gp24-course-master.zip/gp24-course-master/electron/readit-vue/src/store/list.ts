import storage from 'store'

export const list = {
  namespaced: true,
  
  state: {
    list: []
  },
  
  mutations: {
    setList(state, item) {
      state.list.push(item)
      storage.set('list', state.list)
    },
    loadList(state) {
      const list = storage.get('list')
      if (list) {
        state.list = list
      }
    }
  },

  getters: {
    filteredList(state, getters, rootState) {
      const keywords = rootState.k.keywords
      return state.list.filter(item => item.title.includes(keywords))
    }
  }
}
