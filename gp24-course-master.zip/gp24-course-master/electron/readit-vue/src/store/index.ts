import { InjectionKey } from 'vue'

import { createStore, Store } from 'vuex'

import { list } from './list'
import { keywords } from './keywords'

type arrList = {
  img?: string, 
  title: string,
  id: string,
  url: string
}

type ltype = {
  list: Array<arrList>
}

type ktype = {
  keywords: string
}

// 为 store state 声明类型
export interface State {
  l: ltype,
  k: ktype
}

// 定义 injection key
export const key: InjectionKey<Store<State>> = Symbol()

export const store = createStore({
  modules: {
    l: list,
    k: keywords
  }
})
