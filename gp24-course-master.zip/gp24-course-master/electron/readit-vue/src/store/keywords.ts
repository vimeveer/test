export const keywords = {
  namespaced: true,

  state: {
    keywords: ''
  },
  
  mutations: {
    setKeywords(state, keywords) {
      state.keywords = keywords
    }
  }
}