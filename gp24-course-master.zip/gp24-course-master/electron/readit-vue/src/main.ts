import { createApp } from 'vue'
import App from './App.vue'
import { store, key } from './store/index'
import router from './router/index'

import 'normalize.css'
import '@/assets/common.css'

const app = createApp(App)
app.use(store, key).use(router).mount('#app')