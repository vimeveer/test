declare interface Window {
  desktopCapturer: any
  getSources: any,
  sendUrl: any,
  receiveData: any
}