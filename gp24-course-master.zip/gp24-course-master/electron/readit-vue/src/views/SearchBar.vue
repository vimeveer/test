<template>
  <div>
    <div class="button" @click="handleClick">
      +
    </div>
    <div class="input">
      <input 
        type="text" 
        v-model="keywords" 
        placeholder="搜索..."
        @keyup="handleKeyUp"
      >
    </div>
  </div>
</template>

<script lang="ts">
import _ from 'lodash'
import { ref, defineComponent } from 'vue'
import { useStore } from 'vuex'
import { key } from '../store'

export default defineComponent({
  emits: ['update:show'],

  setup(props, { emit }) {
    const store = useStore(key)

    const keywords = ref<string>('')

    const handleClick = () => {
      emit('update:show', true)
    }

    const handleKeyUp = _.debounce(function() {
      store.commit('k/setKeywords', keywords.value)
    }, 300)

    return {
      keywords,
      handleClick,
      handleKeyUp
    }
  }
})
</script>

<style lang='stylus' scoped>
div
  height 60px
  background #d3d3d3
  display flex
  align-items center
  justify-content center
  padding-left 10px
  .button
    width 40px
    height 40px
    padding-left 0
    background-color #1e90ff
    border-radius 5px
    font-size 30px
    font-weight bold
    color #fff
    display flex
    justify-content center
    align-items flex-start
    
  .input
    padding-right 10px
    height 36px
    flex 1
    input
      height 100%
      width 100%
      outline none
      border solid 1px #ccc
      border-radius 5px

</style>