<template>
  <div>
    detail
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent({
  
})
</script>

<style lang='stylus' scoped>

</style>