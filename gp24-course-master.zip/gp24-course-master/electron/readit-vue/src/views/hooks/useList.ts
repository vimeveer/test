import { computed } from 'vue'
import { useStore } from 'vuex'
import { key } from '../../store/index'

const useList = () => {
  const store = useStore(key)

  const list = computed(() => {
    return store.getters['l/filteredList']
  })

  return {
    list
  }
}

export default useList