import { ref } from 'vue'
import { useRouter } from 'vue-router'

const useIndex = () => {
  const currentIndex = ref<number>(0)
  // const router = useRouter()

  const handleClick = ({url, index}) => {
    currentIndex.value = index
    // router.push('/details')
    const win = window.open(url, '_blank')

    // win?.close()
  }

  return {
    currentIndex,
    handleClick
  }
}

export default useIndex