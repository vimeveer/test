// This file is required by the index.html file and will
// be executed in the renderer process for that window.
// No Node.js APIs are available in this process because
// `nodeIntegration` is turned off. Use `preload.js` to
// selectively enable features needed in the rendering
// process.

// const path = require('path')
// const fs = require('fs')
// const rs = fs.writeFileSync('/Users/felix/Desktop/test.txt', 'abc')

// const electron = require('electron')
// console.log(electron)

// setTimeout(() => {
//   console.log(window.abc)
// }, 2000)


// let win

// document.querySelector('#new').addEventListener('click', () => {
//   win = window.open('https://electronjs.org', '_blank', 'width=500,height=450,alwaysOnTop=1')
// })

// document.querySelector('#close').addEventListener('click', () => {
//   win.close()
// })

// document.querySelector('#font').addEventListener('click', () => {
//   win.eval("document.getElementsByTagName('body')[0].style.fontFamily = 'Comic Sans MS'")
// })

// setTimeout(() => {
//   console.log(window.ipcR)
// }, 3000)

document.querySelector('#open-window').addEventListener('click', () => {
  shell.openExternal('https://github.com')
  shell.beep()
})

const NOTIFICATION_TITLE = 'Title'
const NOTIFICATION_BODY = 'Notification from the Renderer process. Click to log to console.'
const CLICK_MESSAGE = 'Notification clicked'

new Notification(NOTIFICATION_TITLE, { body: NOTIFICATION_BODY }).onclick = () => console.log(CLICK_MESSAGE)