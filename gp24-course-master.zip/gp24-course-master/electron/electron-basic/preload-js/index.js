// All of the Node.js APIs are available in the preload process.
// It has the same sandbox as a Chrome extension.
const { ipcRenderer, contextBridge, clipboard, shell } = electron = require('electron')
const capture = require('./desktopCap')

window.addEventListener('DOMContentLoaded', () => {  
  contextBridge.exposeInMainWorld('ipcR', ipcRenderer)
  require('./zoom')

  document.querySelector('#catch').addEventListener('click', capture)

  // clipboard
  clipboard.writeText('abc')
  console.log(clipboard.readText())


  const replaceText = (selector, text) => {
    const element = document.getElementById(selector)
    if (element) element.innerText = text
  }

  // document.querySelector('#btn').addEventListener('click', () => {
  //   ipcRenderer.send('btn-click')
  // })
  
  for (const type of ['chrome', 'node', 'electron']) {
    replaceText(`${type}-version`, process.versions[type])
  }



  // 定义收取主进程发送过来的图片的事件
  ipcRenderer.on('receive-image', (e, img) => {
    document.querySelector('#img2').src = img
  })

  contextBridge.exposeInMainWorld('shell', shell)
})