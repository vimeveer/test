const { webFrame } = require('electron')

document.querySelector('#zoom-up').addEventListener('click', () => {
  webFrame.setZoomLevel( webFrame.getZoomLevel() + 1 )
})