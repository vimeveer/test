const { desktopCapturer, clipboard } = require('electron')

module.exports = () => {
  desktopCapturer
    .getSources({ 
      types: ['screen'], 
      thumbnailSize: {
        width: 1000,
        height: 800
      }
    })
    .then((sources) => {
      document.querySelector('#img').src = sources[0].thumbnail.toDataURL()

      // clipboard.writeBuffer('public/buffter', sources[0].thumbnail.toPNG())
    })
}
