const {
  nativeImage,
  ipcMain,
  net
} = require('electron')

// const https = require('https')
const buffer = []
let size = 0

module.exports = (path, wc) => {
  // https.get(path, (res) => {
  //   res.on('data', (chunk) => {
  //     buffer.push(chunk)
  //     size += chunk.length
  //   })

  //   res.on('end', () => {
  //     let buffers = Buffer.concat(buffer, size)
  //     let image = nativeImage.createFromBuffer(buffers)
  //     wc.send('receive-image', image.toDataURL())
  //   })

  // }).on('error', (e) => {
  //   console.error(e);
  // })

  const request = net.request(path)

  request.on('response', (response) => {
    response.on('data', (chunk) => {
      buffer.push(chunk)
      size += chunk.length
    })
    response.on('end', () => {
      let buffers = Buffer.concat(buffer, size)
      let image = nativeImage.createFromBuffer(buffers)
      wc.send('receive-image', image.toDataURL())
    })
  })
  request.end()
}