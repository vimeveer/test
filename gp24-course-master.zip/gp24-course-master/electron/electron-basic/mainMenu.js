module.exports = [
  {
    label: 'Electron',
    submenu: [
      { label: 'Item 1'},
      { label: 'Item 2', submenu: [ { label: 'Sub Item 1'} ]},
      { label: 'Item 3'},
    ]
  },  
  {
    label: 'Edit',
    submenu: [
      { role: 'undo'},
      { role: 'redo'},
      { role: 'copy'},
      { role: 'paste'},
    ]
  },
  {
    label: '动作',
    submenu: [
      {
        label: 'DevTools',
        role: 'toggleDevTools'
      },
      {
        role: 'toggleFullScreen'
      },
      {
        label: 'Greet',
        click: () => {
          console.log('hello')
        },
        accelerator: 'Shift+Alt+G'
      },
      {
        label: '关闭窗口',
        click: (memu, win) => {
          win.hide()
        },
        accelerator: 'Shift+Alt+H'
      }
    ]
  }
]