import { StyleSheet } from 'react-native'
import getBorderWidth from '../../utils/onePixel'

export default StyleSheet.create({
  wrapper: {
    paddingVertical: 10,
    paddingHorizontal: 15
  },

  input: {
    height: 40,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    borderRadius: 5,
    borderWidth: getBorderWidth(),
    borderColor: '#ee742f'
  },

  img: {
    width: 20,
    height: 20
  },

  text: {
    color: '#666'
  }
})