import React, { FC } from 'react'
import { View, Text, Image } from 'react-native'

import styles from './styleSearchBar'

type Props = {
}

const SearchBar:FC<Props> = (props) => {
  return (
    <View
      style={styles.wrapper}
    >
      <View style={styles.input}>
        <Image 
          source={require('../../assets/images/search.png')}
          style={styles.img}
        ></Image>
        <Text style={styles.text}>想吃什么搜这里，如川菜</Text>
      </View>
    </View>
  )
}

export default SearchBar