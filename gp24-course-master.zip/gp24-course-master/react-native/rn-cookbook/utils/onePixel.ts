import { PixelRatio } from 'react-native'

function getBorderWidth() {
  switch(PixelRatio.get()) {
    case 1:
      return 1
    case 2:
      return 0.5
    case 3:
      return 0.3333333
    default:
      return 1
  }
}

export default getBorderWidth