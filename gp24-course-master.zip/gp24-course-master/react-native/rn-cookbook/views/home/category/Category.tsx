import React, { FC, useEffect } from 'react'
import { View, Text } from 'react-native'
import { useNavigation } from '@react-navigation/native'
import store from '../../../store/title'
import { observer } from 'mobx-react'

type Props = {
}

const Category:FC<Props> = (props) => {
  const navigation = useNavigation()

  useEffect(() => {
    // console.log('category')
    // store.setTitle('分类')
  }, [store.title])

  return (
    <View>
      <Text>Category</Text>
    </View>
  )
}

export default observer(Category)