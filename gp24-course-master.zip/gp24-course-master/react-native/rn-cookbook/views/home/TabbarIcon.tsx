import React, { FC, useMemo } from 'react'
import { Image, ImageSourcePropType } from 'react-native'
import styles from './styleHome'

type Props = {
  focused: boolean,
  icon: string,
  activeIcon: string
}

const TabbarIcon:FC<Props> = ({ focused, icon, activeIcon }) => {
  // const source = focused ? activeIcon : icon
  // const source = useMemo(() => {
  //   return s
  // }, [])

  return (
    <Image
      source={(focused
        ? activeIcon
        : icon) as ImageSourcePropType}
      // source={source}
      style={styles.tabImage2}
    ></Image>
  )
}

export default TabbarIcon