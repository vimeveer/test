import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  tabImage: {
    width: 30,
    height: 30
  },
  tabImage2: {
    width: 26,
    height: 26
  }
})