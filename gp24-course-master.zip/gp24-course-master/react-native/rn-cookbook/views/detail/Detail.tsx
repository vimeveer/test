import React, { FC, useEffect } from 'react'
import { View, Text } from 'react-native'
import { useNavigation } from '@react-navigation/native'

type Props = {
}

const Detail:FC<Props> = (props) => {
  const navigator = useNavigation()

  useEffect(() => {
    navigator.setOptions({
      title: '详细'
    })
  })

  return (
    <View>
      <View>
        <Text>拍照</Text>
      </View>
    </View>
  )
}

export default Detail