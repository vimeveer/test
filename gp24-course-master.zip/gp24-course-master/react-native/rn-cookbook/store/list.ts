import { makeAutoObservable, runInAction } from 'mobx'
import axios from 'axios'

class List {
  list: Array<any> = []

  get swiperList() {
    return this.list.slice(0, 5)
  }

  get top10List() {
    return this.list.slice(0, 10)
  }

  constructor() {
    makeAutoObservable(this)
  }

  async setList() {
    let result = await axios.get('http://localhost:9000/list')
    runInAction(() => {
      this.list = result.data.data
    })
  }
}

export default new List()