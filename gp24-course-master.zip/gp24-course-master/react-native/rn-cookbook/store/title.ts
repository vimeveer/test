import { makeAutoObservable } from 'mobx'

class Title {
  title: string = '美食大全'

  constructor() {
    makeAutoObservable(this)
  }

  setTitle(title: string) {
    this.title = title
  }
}

export default new Title()