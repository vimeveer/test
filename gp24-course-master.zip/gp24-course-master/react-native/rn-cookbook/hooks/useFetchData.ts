import React, { useState, useEffect, useCallback } from 'react'
import axios from 'axios'

const useFetchData = (url: string) => {
  const [list, setList] = useState<Array<{[props: string]: any}>>([])

  const fetchData = useCallback(
    async () => {
      let result = await axios.get(url)
      if (Array.isArray(result.data)) {
        setList(result.data)
      } else {
        setList(result.data.data)
      }
    },
    [],
  )

  useEffect(() => {
    fetchData()
  }, [])

  return {
    list
  }
}

export default useFetchData