import React from 'react'
import { View, Text, StyleSheet, ImageBackground } from 'react-native'

// import Index from './components/01-core-comp/Index'
// import Index from './components/02-textinput/Index'
// import Index from './components/03-scrollable/Index'
// import Index from './components/04-flatlist/Index'
// import Index from './components/04-flatlist/Index-Sectionlist'
// import Index from './components/05-multi-platform/Index'
// import Index from './components/06-styles/Index'
import Index from './components/07-touches/Index'

export default () => {
  return (
    <View style={styles.container}>
      <ImageBackground 
        source={{
          uri: 'https://t7.baidu.com/it/u=1595072465,3644073269&fm=193&f=GIF'
        }} 
        style={{
          width: '100%', height: '100%',
          opacity: 0.3
        }}
      >
      </ImageBackground>
      <View
        style={{
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          position: 'absolute',
          justifyContent: 'center',
          alignItems: 'center'
        }}
      >
        <Index></Index>
      </View>
    </View>


  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative'
  },
  text: {
    fontSize: 50,
    color: 'green'
  }
})
