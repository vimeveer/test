import React, { useCallback } from 'react'
import { View, Text, FlatList } from 'react-native'

export default function Index() {

  const _renderItem = useCallback(
    ({ item }) => {
      return (
        <View>
          <Text>{item.key}</Text>
        </View>
      )
    },
    [],
  )
  return (
    <FlatList
      data={[
        {key: 'Devin'},
        {key: 'Dan'},
        {key: 'Dominic'},
        {key: 'Jackson'},
        {key: 'James'},
        {key: 'Joel'},
        {key: 'John'},
        {key: 'Jillian'},
        {key: 'Jimmy'},
        {key: 'Julie'},
      ]}
      renderItem={_renderItem}
    >
    </FlatList>
  )
}
