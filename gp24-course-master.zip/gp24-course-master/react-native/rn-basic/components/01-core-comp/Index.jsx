import React from 'react'
import { 
  View, 
  Text,
  Image,
  TextInput,
  ScrollView
} from 'react-native'

export default function Index() {
  return (
    <ScrollView style={{width: '100%'}}>
      <View style={{width: '100%'}}>
        <Text>hello world</Text>
      </View>
      <View>
        <Image
          source={{
            uri: 'https://reactnative.dev/docs/assets/p_cat2.png'
          }}
          style={{width: 300, height: 600}}
        ></Image>
      </View>
      <View>
        <TextInput
          style={{
            borderWidth: 1,
            width: 300
          }}
        ></TextInput>
      </View>
      <View style={{height: 800}}>
        <Text>some text</Text>
      </View>
    </ScrollView>
  )
}
