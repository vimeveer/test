import React from 'react'
import { View, Text, Image } from 'react-native'

export default function Index() {
  return (
    <View
      style={{
        backgroundColor: 'red',
        width: 200,
        height: 40,
        justifyContent: 'center'
      }}
    >
      <View 
        style={{
          backgroundColor: 'yellow', 
        }}
      >
        <Text>hello</Text>
      </View>
      <View>
        <Image
          source={require('../../assets/favicon.png')}
        ></Image>
        <Image
          source={{
            uri: 'https://t7.baidu.com/it/u=1595072465,3644073269&fm=193&f=GIF',
            method: 'get'
          }}
          style={{width: 100, height: 100}}
        ></Image>
      </View>
    </View>
  )
}
