import React from 'react'
import { View, Text } from 'react-native'

export default function BodyIos() {
  return (
    <View>
      <Text>body ios</Text>
    </View>
  )
}
