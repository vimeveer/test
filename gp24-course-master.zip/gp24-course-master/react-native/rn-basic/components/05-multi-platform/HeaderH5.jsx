import React from 'react'
import { View, Text } from 'react-native'

export default function HeaderH5() {
  return (
    <View style={{height: 60, backgroundColor: '#6435c9'}}>
      <Text>h5 header</Text>
    </View>
  )
}
