import React from 'react'
import { View, Text } from 'react-native'

export default function HeaderIos() {
  return (
    <View style={{height: 60, backgroundColor:'green'}}>
      <Text>ios header</Text>
    </View>
  )
}
