import React from 'react'
import { View, Text, ScrollView } from 'react-native'

export default function Index() {
  return (
    <View style={{width: '100%'}}>
      <ScrollView 
        style={{borderWidth: 1, height: 100, width: '90%'}}
        // onScroll={() => { console.log(0) }}
        // scrollEventThrottle={16}
        horizontal={true}
      >
        <Text>hello</Text>
      </ScrollView>
      <ScrollView style={{height: 100, width: '90%', borderWidth: 1, marginTop: 20}}>
        <Text>world</Text>
      </ScrollView>
    </View>
  )
}
