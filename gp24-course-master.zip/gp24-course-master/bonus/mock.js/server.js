var Mock = require('mockjs')
var data = Mock.mock({
  "data|3-5": [
    {
      "img": "@image('200x100', '@color()', '@color()', 'png', '@cword(5)')",
      "title": "@cword(5)"
    }
  ]
})

console.log(JSON.stringify(data, null, 2))