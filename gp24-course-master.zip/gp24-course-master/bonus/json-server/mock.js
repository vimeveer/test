const data = require('./data.json')
const list = require('./list.json')

module.exports = function() {
  return {
    data,
    list
  }
}