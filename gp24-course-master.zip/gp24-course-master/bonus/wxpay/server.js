const Koa = require('koa')
const axios = require('axios')

const koa = new Koa()

koa.use(async (ctx, next) => {
  const result = await axios({
    url: 'https://api.mch.weixin.qq.com/v3/pay/transactions/native',
    // url: 'https://api.mch.weixin.qq.com/pay/unifiedorder',
    method: 'post',
    headers: {
      'content-type': 'application/json; charset=utf-8'
    },
    data: {
      appid: 'wx100749d4612ea385',
      mchid: '1448624302',
      description: '一听可乐',
      out_trade_no: '001',
      notify_url: 'https://localhost:3333/notify',
      amount: {
        total: 1,
        currency: 'CNY'
      }
    }
  })
  console.log(result)
  ctx.body = 'abc'
})

koa.listen(3333, () => {
  console.log('localhost:3333')
})