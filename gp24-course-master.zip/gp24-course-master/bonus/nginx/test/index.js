const str = 'ab2'

const exp = /a(b)(\d)/gi
const result = exp.test(str)
const $1 = RegExp.$1
const $2 = RegExp.$2
console.log($2)