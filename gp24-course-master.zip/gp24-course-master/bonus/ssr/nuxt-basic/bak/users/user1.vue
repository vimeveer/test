<template>
  <div>
    user1
  </div>
</template>

<script>
export default {
  // middleware: 'page'
  layout: 'blog',

  asyncData({params}) {
    console.log(params)
    // return {
      
    // }
  }
}
</script>

<style lang='stylus' scoped>

</style>