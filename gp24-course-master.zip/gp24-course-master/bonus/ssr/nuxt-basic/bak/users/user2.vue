<template>
  <div>
    user2

    <nuxt-child></nuxt-child>
  </div>
</template>

<script>
export default {
  layout: 'blog'
}
</script>

<style lang='stylus' scoped>

</style>