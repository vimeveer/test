<template>
  <div>
    user 22
  </div>
</template>

<script>
export default {
  transition: 'test'
}
</script>

<style lang='stylus'>

</style>