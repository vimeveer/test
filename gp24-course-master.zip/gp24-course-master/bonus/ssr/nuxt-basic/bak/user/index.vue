<template>
  <div>
    user/index
  </div>
</template>

<script>
export default {
  
}
</script>

<style lang='stylus' scoped>

</style>