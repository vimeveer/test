<template>
  <div>
    id - {{$route.params.id}}
  </div>
</template>

<script>
export default {
  validate({ params }) {
    // 必须是number类型
    return /^\d+$/.test(params.id)
  },

  mounted() {
    // console.log(this.$route.params.id)
  }
}
</script>

<style lang='stylus' scoped>

</style>