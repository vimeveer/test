<template>
  <div>
    category page

    <nuxt-child></nuxt-child>
  </div>
</template>

<script>
export default {
  asyncData({params}) {
    console.log(params)
    // return {
      
    // }
  }
}
</script>

<style lang='stylus' scoped>

</style>