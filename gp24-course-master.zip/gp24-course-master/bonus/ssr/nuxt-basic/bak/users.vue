<template>
  <div>
    <nuxt-link to="/users/user1">user1</nuxt-link>
    <nuxt-link to="/users/user2">user2</nuxt-link>
    <nuxt-child/>
  </div>
</template>

<script>
export default {
  layout: 'blog'
}
</script>

<style lang='stylus' scoped>

</style>