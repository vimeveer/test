<template>
  <div>
    slug/index
  </div>
</template>

<script>
export default {
  asyncData({params}) {
    console.log(params)
    // return {
      
    // }
  }
}
</script>

<style lang='stylus' scoped>

</style>