export default (args) => {
  console.log(0)
}