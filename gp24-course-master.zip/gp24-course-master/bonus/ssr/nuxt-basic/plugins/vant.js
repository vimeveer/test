import Vue from 'vue'
import Vant from 'vant'

Vue.use(Vant)
