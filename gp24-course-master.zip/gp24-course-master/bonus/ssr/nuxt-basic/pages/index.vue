<template>
  <div>
    {{title}} - {{msg}}
  </div>
</template>

<script>
export default {
  data() {
    return {
      title: 'hello'
    }
  },

  asyncData() {
    return {
      msg: 'world'
    }
  }
}
</script>

<style lang='stylus' scoped>

</style>