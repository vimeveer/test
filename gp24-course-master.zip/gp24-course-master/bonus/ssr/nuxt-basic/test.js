const { waterfall } = require('async');
const parallel = require('async/parallel')
const series = require('async/series')

console.time('test')


// parallel([
//   function(callback) {
//     setTimeout(() => {
//       callback(null, 200)
//     }, 2000)
//   },
//   function(callback) {
//     setTimeout(() => {
//       callback(null, 100)
//     }, 1000)
//   }
// ], function(err, result) {
//   console.timeEnd('test')

//   console.log(result)
// })

// parallel({
//   aaa(callback) {
//     setTimeout(() => {
//       callback(null, 200)
//     }, 2000)
//   },

//   bbb(callback) {
//     setTimeout(() => {
//       callback(null, 100)
//     }, 1000)
//   }
// }, function(err, result) {
//   console.timeEnd('test')

//   console.log(result)
// })

// ;(async function(){
//   let result = await new Promise((resolve) => {
//     setTimeout(() => {
//       resolve(100)
//     }, 2000)
//   })

//   console.log(result)
// })()

// ;(async function(){
//   let result = await parallel([
//     function(callback) {
//       setTimeout(() => {
//         callback(null, 200)
//       }, 2000)
//     },
//     function(callback) {
//       setTimeout(() => {
//         callback(null, 100)
//       }, 1000)
//     }
//   ])

//   console.log(result)
// })()

// 串行无关连
// ;(async function(){
//   let result = await series([
//     function(callback) {
//       setTimeout(() => {
//         callback(null, 200)
//       }, 2000)
//     },
//     function(callback) {
//       setTimeout(() => {
//         callback(null, 100)
//       }, 1000)
//     }
//   ])

//   console.timeEnd('test')
//   console.log(result)
// })()

// 串行有关联
;(async function(){
  let result = await waterfall([
    function(callback) {
      setTimeout(() => {
        callback(null, 200)
      }, 2000)
    },
    function(args, callback) {
      setTimeout(() => {
        callback(null, 100 + args)
      }, 1000)
    }
  ])

  console.timeEnd('test')
  console.log(result)
})()