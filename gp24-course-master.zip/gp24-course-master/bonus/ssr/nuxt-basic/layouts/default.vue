<template>
  <div>
    <h3>我是人类：</h3>
    <nuxt />
  </div>
</template>