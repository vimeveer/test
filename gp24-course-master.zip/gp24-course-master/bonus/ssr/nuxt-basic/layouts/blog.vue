<template>
  <div>
    <h3>我是神：</h3>
    <nuxt></nuxt>
  </div>
</template>