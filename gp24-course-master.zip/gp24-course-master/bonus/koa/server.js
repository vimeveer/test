const Koa = require('koa')

const koa = new Koa()

koa.use(async (ctx, next) => {
  console.log(0)
  let result = await next()
  console.log(result)
})

koa.use(async (ctx, next) => {
  console.log(1)
  ctx.body = 'hello'
  return 'abc'
})

koa.listen(3333, () => {
  console.log('localhost:3333')
})