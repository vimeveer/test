var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/def', function(req, res, next) {
  res.cookie('age', '18')
  res.json({
    y: 200
  })
});

router.get('/abc', function(req, res, next) {
  console.log(0)
  console.log(req.cookies)
  res.json({
    x: 100
  })
});

module.exports = router;
