const http = require('http')

const app = http.createServer((req, res) => {
  res.writeHead(200, {
    'content-type': 'text/html',
    'server': 'Apache',
    'set-cookie': 'name=value'
  })
  res.write('hello')
  res.end()
})

app.listen(3000, () => {
  console.log('localhost:3000')
})